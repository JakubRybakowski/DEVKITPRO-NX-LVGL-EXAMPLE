build/__UI_PROJECT_NAME__
#gdb  -ex=r  build/__UI_PROJECT_NAME__  -ex='bt'  --batch  # -ex='bt'  -ex=quit
#valgrind  build/__UI_PROJECT_NAME__  --leak-check=full
